/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eindopdrachtowe6aaditichoudhry;

import java.util.*;
import javax.swing.JTextArea;

/**
 *  dit zou de de gefilterde resultaten moeten plaatsen.
 * filters als in de knopjes die horen onder sorteren en de classificatie op wat voor een soort virus je naar opzoek bent.
 * @author aditi
 */
public class VirusLogica {
    private HashMap<String, Virus>virusMap = new HashMap();
    private HashMap<String, Host>hostMap = new HashMap();
    
    private ArrayList<Virus> virusList = new ArrayList();
    
    public ArrayList<Virus> getVirussesWithClassification() {
        return new ArrayList();
    }
    
    public ArrayList<Virus> filterVirussesForHost(String host) {
        return new ArrayList();
    }
    
    public ArrayList<Virus> filterSimilarities(ArrayList<Virus> unfilteredList) {
        return new ArrayList();
    }

    public void selectNormal(JTextArea field, Host selected){
        field.setText(selected.getVirusses().toString().replace(",","\n").replace("[","").replace("]","").replace(" ", ""));
    }

    /**
     * methode van de gekozen virussen/hosts die vergeleken worden met elkaar en de overeenkomsten laten zien.
     * @param l1
     * @param l2
     * @return 
     */
    
    public ArrayList selectComparedOnes(ArrayList<String> l1,ArrayList<String> l2){
        ArrayList<String> overeenkomsten = new ArrayList();
        overeenkomsten.add("");
        if(l1.size()>l2.size()){
            l1.stream().filter((x) -> (l2.contains(x))).forEach((x) -> {
                overeenkomsten.add(x);
            });
        }else{
            l2.stream().filter((x) -> (l1.contains(x))).forEach((x) -> {
                overeenkomsten.add(x);
            });
        }
        return overeenkomsten;
    }

}

