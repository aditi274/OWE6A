/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eindopdrachtowe6aaditichoudhry;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.*;
import java.nio.channels.*;
import java.util.*;
import javax.swing.*;
import javax.swing.JFileChooser;
import java.net.*;

/**
 *
 * @author aditi
 */
public class EindopdrachtOwe6aAditiChoudhry {
// maken van variabelen
    private static int TAX_ID = 0;
    private static int VIRUS_NAME = 1;
    private static int VIRUS_LINEAGE = 2;
    private static int REFSEQ_ID = 3;
    private static int KEGG_GENOME = 4;
    private static int KEGG_DISEASE = 5;
    private static int DISEASE = 6;
    private static int HOST_TAX_ID = 7;
    private static int HOST_NAME = 8;
    private static int HOST_LINEAGE = 9;
    private static int PMID = 10;
    private static int EVIDENCE = 11;

    //maken vna hashmaps
    static HashMap<String, Virus> virusMap = new HashMap();
    static HashMap<String, Host> hostMap = new HashMap();

    /**
     * @param args the command line arguments
     * 
     */
    public static void main(String[] args) {
        VirusGUI Gui = new VirusGUI();
        Gui.setVisible(true);
    }
    
    /**
     * ophalen van URL en de online gegevens
     * @param location
     * @param h1
     * @param h2
     * @throws MalformedURLException
     * @throws IOException 
     */

    public static void getURL(String location, JComboBox h1, JComboBox h2) throws MalformedURLException, IOException {
        getFile(location);
        updateGUI(h1, h2);
    }
    
    /**
     * ophalen van gegevens van de file en het sorteren ervan op hosts en virus
     * @param source 
     */

    private static void getFile(String source) {
        JFileChooser fileChooser = new JFileChooser();
        try {
            //BufferedReader inFile;
            //inFile = new BufferedReader(new FileReader(source));
            //String line;

            int lineNum = 0;

            URL url = new URL(source);
            Scanner s = new Scanner(url.openStream());

            while (s.hasNext()) {
                String line = s.nextLine();
                System.out.println("Checking line: " + line);
                String[] lineList = line.split("\\t");

                try {
                    Integer.parseInt(lineList[EindopdrachtOwe6aAditiChoudhry.TAX_ID]);
                } catch (Exception e) {
                    continue;
                }

                if (lineNum == 0) {
                    lineNum++;
                } else {
                    try {
                        Virus virus = null;

                        if (virusMap.containsKey(Integer.parseInt(lineList[EindopdrachtOwe6aAditiChoudhry.TAX_ID]))) {
                            virus = virusMap.get(EindopdrachtOwe6aAditiChoudhry.TAX_ID);
                        } else {
                            virus = new Virus(
                                    lineList[EindopdrachtOwe6aAditiChoudhry.VIRUS_NAME],
                                    lineList[EindopdrachtOwe6aAditiChoudhry.VIRUS_LINEAGE],
                                    lineList[EindopdrachtOwe6aAditiChoudhry.TAX_ID]);

                            virusMap.put(virus.getID(), virus);
                        }

                        if (virus == null) {
                            for (int i = 0; i < lineList.length; i++) {
                                System.out.println(lineList[i]);
                            }

                            System.out.println(line);
                            throw new RuntimeException("yoooow");
                        }

                        Host host = null;

                        try {
                            if (hostMap.containsKey(lineList[EindopdrachtOwe6aAditiChoudhry.HOST_TAX_ID])) {
                                host = hostMap.get(lineList[EindopdrachtOwe6aAditiChoudhry.HOST_TAX_ID]);
                            } else {
                                host = new Host(
                                        lineList[EindopdrachtOwe6aAditiChoudhry.HOST_TAX_ID],
                                        lineList[EindopdrachtOwe6aAditiChoudhry.HOST_NAME],
                                        virus);

                                hostMap.put(host.getId(), host);
                            }
                        } catch (Exception e) {

                        }

                        if (host != null) {
                            if (!host.getVirusses().contains(virus)) {
                                host.addVirus(virus);
                            }

                            if (!virus.getHosts().contains(host)) {
                                virus.addHost(host);
                            }
                        }
                        /**
                         * catchen van exceptions
                         */

                    } catch (ArrayIndexOutOfBoundsException e) {
                        e.printStackTrace();

                        System.out.println("Warning:"
                                + "virus without host!");

                    } catch (NumberFormatException e) {
                        System.out.println("Can't read line: " + line);
                    }
                }

            }
        } catch (FileNotFoundException fnfe) {
            System.out.println("File not found");
        } catch (IOException ioe) {
            System.out.println("Can't read file");
        }

        System.out.println("Finished checking virusses");
    }
    
    /**
     * vult de combo boxen met de Hosts
     * @param h1
     * @param h2 
     */

    public static void updateGUI(JComboBox h1, JComboBox h2) {
        h1.removeAllItems();
        h2.removeAllItems();

        for (String x : hostMap.keySet()) {
            if (hostMap.get(x).getVirusses().size() > 1) {
                System.out.println("host with multiple ");

            }

            h1.addItem("(" + x + ")" + hostMap.get(x).getName());
            h2.addItem("(" + x + ")" + hostMap.get(x).getName());
        }
    }

    // sort 0 = id
    // sort 1 = classification
    // sort 2 = number of hosts
    // sort 3 = nothing
    
    /**
     * Textarea's worden gevuld met de gekozen virussen en gesorteerd. dit onderdeel hoort bij viruslogica.
     * @param selectedHost
     * @param textArea
     * @param sort 
     */
    public static void fillVirusList(String selectedHost, JTextArea textArea, int sort) {
        Host host = hostMap.get(selectedHost);

        if (host != null) {
            ArrayList<Virus> list = host.getVirusses();

            if (sort == 0) {
                list.sort(new Comparator<Virus>() {
                    @Override
                    public int compare(Virus v1, Virus v2) {
                        return v1.getID().compareTo(v2.getID());
                    }
                });
            }

            String virusString = "";

            for (int i = 0; i < list.size(); i++) {
                virusString += list.get(i).getID() + ": " + list.get(i).getName();
                virusString += "\n";
            }

            textArea.setText(virusString);
        }
    }
    
    /**
     * de vergelijkingen worden uitgewerkt door de ArrayLists te vergelijken.
     * @param h1
     * @param h2
     * @param textArea 
     */

    public static void fillComparedList(String h1, String h2, JTextArea textArea) {
        Host host1 = hostMap.get(h1);
        Host host2 = hostMap.get(h2);

        ArrayList<Virus> sameVirusses = new ArrayList<Virus>();

        if (host1 != null && host2 != null) {
            ArrayList<Virus> list = host1.getVirusses();
            ArrayList<Virus> list2 = host2.getVirusses();

            for (int i = 0; i < list.size(); i++) {
                Virus virus1 = list.get(i);

                for (int j = 0; j < list2.size(); j++) {
                    Virus virus2 = list2.get(j);

                    if (virus2.getID().equals(virus1.getID())) {
                        sameVirusses.add(virus1);
                    }
                }
            }

            String virusString = "";

            for (int i = 0; i < sameVirusses.size(); i++) {
                virusString += sameVirusses.get(i).getID() + ": " + sameVirusses.get(i).getName();
                virusString += "\n";
            }

            textArea.setText(virusString);
        }
    }
}
