/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eindopdrachtowe6aaditichoudhry;

import java.awt.List;
import java.util.ArrayList;

/**
 * de virus object met een arraylist die gevuld is met de mogelijke hosts. 
 * de virussen worden eventueel gekoppeld met de mogelijke hosts.
 * @author aditi
 */
public class Virus {
    private String name, classification;
    private ArrayList<Host> hostList = new ArrayList();
    private String ID;
    
    public Virus(){
        System.out.println("Warning:"
                + "Empty virus created!");
    }
    
    public Virus(String name, Host host, String classification, String ID){
        this.name=name;
        this.hostList.add(host);
        this.classification=classification;
        this.ID=ID;
    }
    
    public Virus(String name, String classification, String ID){
        this.name=name;
        this.classification=classification;
        this.ID=ID;
    }
    /**
     * getters en setters. De setters worden getoond door middel van returns.
     * @return 
     */
    
    String getID(){
        return(this.ID);
    }
    
    int getCountHost(){
        return hostList.size();
    }
    
    String getName(){
        return(this.name);
    }
    
    String getClassifcation(){
        return(this.classification);
    }
    
    ArrayList getHosts(){
        return(this.hostList);
    }
    
    void addHost(Host host){
        this.hostList.add(host);
    }
    

   
}
