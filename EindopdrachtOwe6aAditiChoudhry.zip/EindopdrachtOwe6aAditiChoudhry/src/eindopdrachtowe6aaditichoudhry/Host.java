/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eindopdrachtowe6aaditichoudhry;

import java.awt.List;
import java.util.ArrayList;
/**
 * een host object die gevuld is met de mogelijke virussen.
 * @author aditi
 */
public class Host {
    
    private String hostId;
    private String hostName;
    private ArrayList<Virus> virus;

    public Host(String id, String name, Virus virus) {
        this.hostId = id;
        this.hostName = name;
        this.virus = new ArrayList();
        this.virus.add(virus);
    }
    /**
     * getters en setters.
     * @return 
     */
    public String getId() {
        return hostId;
    }
    
    public String getName() {
        return hostName;
    }
    
    void addVirus(Virus virus){
        this.virus.add(virus);
    }
    
    ArrayList getVirusses(){
        return this.virus;
    }
    
}
